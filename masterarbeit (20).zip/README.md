# Master's thesis
*-- Simultaneous localization and classification of environmental sounds using deep learning techniques --*

## Abstract